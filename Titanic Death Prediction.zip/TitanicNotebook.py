# %% [code]
import numpy as np
import pandas as pd

# %% [code]
df=pd.read_csv('../input/titanic/train.csv')

# %% [code]
df.head()

# %% [code]
def extraction(a):
  b=a.split(',',2)
  return b[0]
df['PsudoName']=df['Name'].apply(extraction)
df.head()

# %% [code]
lst=list(df['PsudoName'])
dic=dict( (x, lst.count(x) ) for x in set(lst))
print(dic)

# %% [code]
b=list(dic.values())
b.sort(reverse=True)
print(b)

# %% [code]
#as there are too many different types of object so this will not gonna useful for the analysis. So we can delete the Name attribute

col=df.columns
for j in range(13):
    w=df.iloc[:,j].isnull().sum()
    print(col[j],"\t\t\t",w/len(df))  

# %% [code]
# there are too many blank space in the Cabin attribute, so we'll delete this too

def spliter(a):
  b=str(a)
  x=b.split(' ')
  return x
df['Ticket']=df['Ticket'].apply(spliter)
def changer(a):
  if len(a)>2:
    if a[1].isnumeric() is False:
      b=[a[0],a[2]]
      return b
    else:
      x=a[0]+a[1]
      b=[x,a[2]]
      return b
  else:
    return a
df['Ticket']=df['Ticket'].apply(changer)
df.head()

# %% [code]
def div(a):
  if len(a) is 1:
    return a[0]
  else:
    return a[1]
df['TicketNumber']=df['Ticket'].apply(div)

# %% [code]
def txt(a):
  a=list(a)
  if len(a)>1:
    return a[0]
  else:
    return 'NA'
df['TicketCode']=df['Ticket'].apply(txt)
df.head()

# %% [code]
df1=df[df['TicketNumber']=='LINE']
df1.head()

# %% [code]
def num(a):
  a=list(a)
  if len(a)>1:
    return a[1]
  elif a[0][0].isnumeric()==True:
    return a[0]
  else:
    return '0'
df['TicketNumber']=df['Ticket'].apply(num)
df.head()

# %% [code]
df1=df[df['TicketNumber']=='0']
df1.head()

# %% [code]
col=df.columns
for j in range(15):
    w=df.iloc[:,j].isnull().sum()
    print(col[j],"\t\t\t",w/len(df))  

# %% [code]
#we're gonna use the ave to fill the rest of the Age attributes and ffill to fill rest of Embarked attributes

a=list(df['Age'])
print(a)

# %% [code]
s=0
i=0
for j in a:
  if j>0 and j<150:
    s+=j
    i+=1
ave=s/i
print(ave)

# %% [code]
def replaced(a):
  if a>0 and a<150:
    return a
  else:
    return ave
df['Age']=df['Age'].apply(replaced)
df.head()

# %% [code]
df.fillna(method='ffill',inplace=True)
col=df.columns
for j in range(15):
    w=df.iloc[:,j].isnull().sum()
    print(col[j],"\t\t\t",w/len(df))  

# %% [code]
from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
df.iloc[:,4]=le.fit_transform(df.iloc[:,4])
df.iloc[:,11]=le.fit_transform(df.iloc[:,11])
df.iloc[:,14]=le.fit_transform(df.iloc[:,14])
df.head()

# %% [code]
col=['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked', 'TicketNumber', 'TicketCode']
X_train=df[col]
X_train.head()

# %% [code]
y_train=df['Survived']
y_train.head()

# %% [code]
dfTest=pd.read_csv('../input/titanic/test.csv')
dfTest.head()

# %% [code]
def spliter(a):
  b=str(a)
  x=b.split(' ')
  return x
dfTest['Ticket']=dfTest['Ticket'].apply(spliter)
def changer(a):
  if len(a)>2:
    if a[1].isnumeric() is False:
      b=[a[0],a[2]]
      return b
    else:
      x=a[0]+a[1]
      b=[x,a[2]]
      return b
  else:
    return a
dfTest['Ticket']=dfTest['Ticket'].apply(changer)
dfTest.head()

# %% [code]
def div(a):
  if len(a) is 1:
    return a[0]
  else:
    return a[1]
dfTest['TicketNumber']=dfTest['Ticket'].apply(div)
def txt(a):
  a=list(a)
  if len(a)>1:
    return a[0]
  else:
    return 'NA'
dfTest['TicketCode']=dfTest['Ticket'].apply(txt)
dfTest.head()

# %% [code]
dfTest1=dfTest[dfTest['TicketNumber']=='LINE']
dfTest1.head()

# %% [code]
col=dfTest.columns
for j in range(13):
    w=dfTest.iloc[:,j].isnull().sum()
    print(col[j],"\t\t\t",w/len(dfTest))   

# %% [code]
a=list(dfTest['Age'])
b=list(dfTest['Fare'])
s=0
i=0
for j in a:
  if j>0 and j<150:
    s+=j
    i+=1
ave1=s/i
s=0
i=0
for j in b:
  if j>0.0 and j<550.0:
    s+=j
    i+=1
ave2=s/i
print(ave1,ave2)

# %% [code]
def replaced1(a):
  if a>0 and a<150:
    return a
  else:
    return ave1
dfTest['Age']=dfTest['Age'].apply(replaced1)
def replaced2(a):
  if a>0 and a<550:
    return a
  else:
    return ave2
dfTest['Fare']=dfTest['Fare'].apply(replaced2)
dfTest.head()

# %% [code]
print(list(dfTest['Fare']))

# %% [code]
col=dfTest.columns
for j in range(13):
    w=dfTest.iloc[:,j].isnull().sum()
    print(col[j],"\t\t\t",w/len(dfTest))   

# %% [code]
dfTest.iloc[:,3]=le.fit_transform(dfTest.iloc[:,3])
dfTest.iloc[:,10]=le.fit_transform(dfTest.iloc[:,10])
dfTest.iloc[:,12]=le.fit_transform(dfTest.iloc[:,12])
dfTest.head()

# %% [code]
col=['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked', 'TicketNumber', 'TicketCode']
X_test=dfTest[col]
X_test.head()

# %% [code]
df3=pd.read_csv('../input/titanic/gender_submission.csv')
df3.head()

# %% [code]
list(dfTest['PassengerId'])==list(df3['PassengerId'])

# %% [code]
#Hence we can use this data as y_test

y_test=df3['Survived']
y_test.head()

# %% [code]
#Decision Tree algo for various depth

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
for i in range(2,15):
  clf = DecisionTreeClassifier(max_depth=i)
  clf = clf.fit(X_train,y_train)
  y_pred = clf.predict(X_test)
  print("Accuracy:",accuracy_score(y_test, y_pred))

# %% [code]
#Random Forest algo for various number of trees


from sklearn.ensemble import RandomForestClassifier
for i in range(16):
  j=300+i*25
  classifier = RandomForestClassifier(n_estimators =j)
  classifier.fit(X_train, y_train)
  y_pred = classifier.predict(X_test)
  print("Accuracy:",accuracy_score(y_test, y_pred))

# %% [code]
#Logistic Regression

from sklearn import datasets, linear_model 
reg = linear_model.LogisticRegression() 
reg.fit(X_train, y_train) 
y_pred = reg.predict(X_test) 
print("Accuracy:",  accuracy_score(y_test, y_pred)) 

# %% [code]
#Naive Bayes

from sklearn.naive_bayes import GaussianNB 
gnb = GaussianNB() 
gnb.fit(X_train, y_train) 
y_pred = gnb.predict(X_test)  
from sklearn import metrics 
print("Accuracy:", metrics.accuracy_score(y_test, y_pred))

# %% [code]
#KNN for various values of k

from sklearn.neighbors import KNeighborsClassifier
for j in range(1,30):
  knn = KNeighborsClassifier(n_neighbors=j)
  knn.fit(X_train, y_train)
  y_pred = knn.predict(X_test)
  from sklearn import metrics
  print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

# %% [code]
#SVM

from sklearn.svm import SVC
svm = SVC()
svm.fit(X_train, y_train)
y_pred = svm.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

# %% [code]
from sklearn.ensemble import VotingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn import model_selection

estimators=[('svm', svm),('naive',gnb),('logistic',reg)]

dst=DecisionTreeClassifier(max_depth=3)
estimators.append(('decissionTree', dst))

rdf=RandomForestClassifier(n_estimators =j)
estimators.append(('randomForest', rdf))

knn = KNeighborsClassifier(n_neighbors=4)
estimators.append(('KNN', knn))

kfold = model_selection.KFold(n_splits=10, random_state=7)
ensemble = VotingClassifier(estimators)
results = model_selection.cross_val_score(ensemble, X_train, y_train, cv=kfold)
print(results.mean())

# %% [code]
#So we can see the best result we get in the Decission Tree algo with max dept lies between 3 to 5

dst=DecisionTreeClassifier(max_depth=3)
dst = dst.fit(X_train,y_train)
y_pred = dst.predict(X_test)
print("Accuracy for 3:",accuracy_score(y_test, y_pred))

dst=DecisionTreeClassifier(max_depth=4)
dst = dst.fit(X_train,y_train)
y_pred = dst.predict(X_test)
print("Accuracy for 4:",accuracy_score(y_test, y_pred))

dst=DecisionTreeClassifier(max_depth=5)
dst = dst.fit(X_train,y_train)
y_pred = dst.predict(X_test)
print("Accuracy for 5:",accuracy_score(y_test, y_pred))

# %% [code]
dst=DecisionTreeClassifier(max_depth=3)
dst = dst.fit(X_train,y_train)
y_pred = dst.predict(X_test)
print("Accuracy for 3:",accuracy_score(y_test, y_pred))

# %% [code]
df3.head()

# %% [code]
df3['Survived Prediction']=y_pred
df3.head()

# %% [code]
df3['Match']=(df3['Survived Prediction']+df3['Survived']+1)%2
df3.head()

# %% [code]
x=list(df3['Match'])
y=sum(x)
print(y/len(df3))

# %% [code]
df3.to_csv('/kaggle/working/output.csv')
